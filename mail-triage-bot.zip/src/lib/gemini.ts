import { GoogleGenerativeAI, SchemaType } from "@google/generative-ai";
import { env } from "./env";
import type { OutlookMessage } from "./outlook";

const genAI = new GoogleGenerativeAI(env.GEMINI_API_KEY);

export type Classification = {
  urgency: "instant" | "important" | "normal" | "skip";
  category: string;
  summary_tr: string;
  suggested_action: string;
};

const SYSTEM_PROMPT = `Sen, kullanıcının (Alp — İstanbul'da bir hukuk firmasında çalışan avukat) e-postalarını triajlayan bir AI asistanısın.

Her e-posta için şu kategorilere ayır:
- "instant": Acil aksiyon gerektiren, hemen bildirim almalı (örn. müvekkilden acil talep, deadline'lı talep, mahkeme/duruşma uyarısı, önemli toplantı daveti)
- "important": Aynı gün cevap/aksiyon gerektiren, dijest'e eklenecek (örn. iş maili, müvekkil maili, ödeme talimatı, sözleşme dönüşü)
- "normal": Bilgi amaçlı, dijest'te özet halinde yer alabilir (örn. newsletter, hatırlatma, sıradan bilgilendirme)
- "skip": Tamamen göz ardı edilebilir (örn. otomatik bildirim, spam, reklam, sosyal medya bildirimi, e-fatura otomatik mailı)

Kategori seçerken şu prensipleri uygula:
1. Gönderici domaini önemli: kişisel/kurumsal isim @gmail/@outlook/@şirket → daha önemli; @noreply/@notifications/@news → genelde skip veya normal
2. Konu satırındaki "acil", "ASAP", "today", "deadline", "duruşma", "ihtar" → instant
3. Müvekkil veya iş arkadaşı tonu → important
4. Pazarlama, kampanya, indirim → skip
5. LinkedIn/sosyal medya bildirimleri → skip

summary_tr: Maksimum 2 cümle, Türkçe. Maile bakmadan ne yapması gerektiğini anlamasını sağla.
suggested_action: Tek satır, ne yapmalı (örn. "Bugün cevapla", "İncele", "Görmezden gel", "Toplantı kabul et").
category: Kısa tematik etiket (örn. "Müvekkil", "İş", "Banka", "Newsletter", "Sosyal", "Sistem").`;

const responseSchema = {
  type: SchemaType.OBJECT,
  properties: {
    urgency: {
      type: SchemaType.STRING,
      enum: ["instant", "important", "normal", "skip"],
    },
    category: { type: SchemaType.STRING },
    summary_tr: { type: SchemaType.STRING },
    suggested_action: { type: SchemaType.STRING },
  },
  required: ["urgency", "category", "summary_tr", "suggested_action"],
};

export async function classifyMessage(
  msg: OutlookMessage
): Promise<Classification> {
  const model = genAI.getGenerativeModel({
    model: env.GEMINI_MODEL,
    systemInstruction: SYSTEM_PROMPT,
    generationConfig: {
      responseMimeType: "application/json",
      // @ts-expect-error — schema typing in SDK
      responseSchema,
      temperature: 0.2,
    },
  });

  const userPart = [
    `Gönderen: ${msg.from?.emailAddress?.name ?? "?"} <${msg.from?.emailAddress?.address ?? "?"}>`,
    `Konu: ${msg.subject ?? "(konu yok)"}`,
    `Önem (Outlook): ${msg.importance}`,
    `Önizleme:`,
    msg.bodyPreview?.slice(0, 1500) ?? "(boş)",
  ].join("\n");

  const result = await model.generateContent(userPart);
  const text = result.response.text();

  try {
    return JSON.parse(text) as Classification;
  } catch {
    // Fallback: safe default
    return {
      urgency: "normal",
      category: "Bilinmiyor",
      summary_tr: "Sınıflandırma başarısız, manuel inceleme gerekli.",
      suggested_action: "İncele",
    };
  }
}

/**
 * Generates a consolidated digest summary from multiple emails.
 * Used for the 09:00 and 18:00 digests.
 */
export async function generateDigestSummary(
  items: Array<{
    from: string;
    subject: string;
    summary: string;
    category: string;
  }>
): Promise<string> {
  if (items.length === 0) return "Bu dönemde önemli mail yok. 🎉";

  const model = genAI.getGenerativeModel({
    model: env.GEMINI_MODEL,
    systemInstruction:
      "Sen Alp'in e-posta asistanısın. Aşağıdaki maillerin Türkçe, kısa, Telegram'da okunmaya uygun bir özetini yap. Maddeler halinde, her madde 1 satır. Önce 'important' kategoride olanlar, sonra 'normal'. Emoji kullanma. Markdown bold (*) kullanma. Sonunda toplam mail sayısını belirt.",
    generationConfig: { temperature: 0.3 },
  });

  const formatted = items
    .map(
      (i, idx) =>
        `${idx + 1}. [${i.category}] ${i.from} — "${i.subject}": ${i.summary}`
    )
    .join("\n");

  const result = await model.generateContent(formatted);
  return result.response.text();
}
